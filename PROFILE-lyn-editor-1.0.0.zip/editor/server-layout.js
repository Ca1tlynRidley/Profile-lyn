globalThis.PROFILE_SERVER_LAYOUT = {
  "schemaVersion": 1,
  "title": "{player}'s Profile",
  "rows": 6,
  "filler": "minecraft:gray_stained_glass_pane",
  "items": [
    {
      "slot": 13,
      "item": "minecraft:player_head",
      "count": 1,
      "name": "&b{player}'s Profile",
      "lore": [
        "&7Your survival story, in one place.",
        "&7Players online: &f{online}"
      ],
      "glint": false,
      "action": {
        "type": "none",
        "value": ""
      }
    },
    {
      "slot": 19,
      "item": "minecraft:diamond_sword",
      "count": 1,
      "name": "&cYour Stats",
      "lore": [
        "&7Health: &f{health}/20",
        "&7Hunger: &f{food}/20"
      ],
      "glint": false,
      "action": {
        "type": "none",
        "value": ""
      }
    },
    {
      "slot": 20,
      "item": "minecraft:map",
      "count": 1,
      "name": "&eLocation",
      "lore": [
        "&7X: &f{x} &7Y: &f{y} &7Z: &f{z}"
      ],
      "glint": false,
      "action": {
        "type": "none",
        "value": ""
      }
    },
    {
      "slot": 21,
      "item": "minecraft:book",
      "count": 1,
      "name": "&6Welcome",
      "lore": [
        "&7Click for a friendly message."
      ],
      "glint": false,
      "action": {
        "type": "message",
        "value": "&aWelcome, {player}! Have fun on the server."
      }
    },
    {
      "slot": 22,
      "item": "minecraft:emerald",
      "count": 1,
      "name": "&aYour Wallet",
      "lore": [
        "&7Balance: &a{money}",
        "",
        "&8Powered by ECO-API-lyn",
        "&eClick to check your balance"
      ],
      "glint": true,
      "action": {
        "type": "command",
        "value": "balance"
      }
    },
    {
      "slot": 23,
      "item": "minecraft:experience_bottle",
      "count": 1,
      "name": "&dExperience",
      "lore": [
        "&7Level: &d{level}"
      ],
      "glint": false,
      "action": {
        "type": "none",
        "value": ""
      }
    },
    {
      "slot": 24,
      "item": "minecraft:clock",
      "count": 1,
      "name": "&eRefresh Profile",
      "lore": [
        "&7Stats also update once a second.",
        "&eClick to refresh now"
      ],
      "glint": false,
      "action": {
        "type": "refresh",
        "value": ""
      }
    },
    {
      "slot": 25,
      "item": "minecraft:ender_chest",
      "count": 1,
      "name": "&5Economy Leaders",
      "lore": [
        "&7See the richest players.",
        "&eClick to view /baltop"
      ],
      "glint": false,
      "action": {
        "type": "command",
        "value": "baltop"
      }
    },
    {
      "slot": 31,
      "item": "minecraft:crafting_table",
      "count": 1,
      "name": "&6Your Adventure",
      "lore": [
        "&7Build something great, {player}!"
      ],
      "glint": false,
      "action": {
        "type": "none",
        "value": ""
      }
    },
    {
      "slot": 45,
      "item": "minecraft:compass",
      "count": 1,
      "name": "&bYour Coordinates",
      "lore": [
        "&7{x}, {y}, {z}"
      ],
      "glint": false,
      "action": {
        "type": "none",
        "value": ""
      }
    },
    {
      "slot": 49,
      "item": "minecraft:barrier",
      "count": 1,
      "name": "&cClose Profile",
      "lore": [
        "&7Click to return to the game."
      ],
      "glint": false,
      "action": {
        "type": "close",
        "value": ""
      }
    }
  ]
};
